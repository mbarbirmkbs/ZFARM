package com.example.odataapp01.asyncTasks;

public interface AsyncResponseCowNewEntry {
    void processFinish(String output);
}
