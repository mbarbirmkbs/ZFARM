package com.example.odataapp01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.odataapp01.data.CowState;
import com.example.odataapp01.helpClasses.CowAsyncTask;
import com.example.odataapp01.helpClasses.CowsListAdapter;

import java.util.ArrayList;
import java.util.List;

import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Column;
import lecho.lib.hellocharts.model.ColumnChartData;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.SubcolumnValue;
import lecho.lib.hellocharts.util.ChartUtils;
import lecho.lib.hellocharts.view.ColumnChartView;
import lecho.lib.hellocharts.view.LineChartView;

public class DetailsActivity extends AppCompatActivity implements AsyncResponseDetails {

    private CowState cow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        String bukrs = getIntent().getStringExtra("EXTRA_BUKRS");
        String grlid = getIntent().getStringExtra("EXTRA_GRLID");

        CowAsyncTask myAsyncTask = new CowAsyncTask();

        //this to set delegate/listener back to this class
        myAsyncTask.delegate = this;

        //execute the async task
        myAsyncTask.execute(bukrs,grlid);
        
    }

    //this override the implemented method from asyncTask
    @Override
    public void processFinish(CowState output){
        //Here you will receive the result fired from async class
        //of onPostExecute(result) method.
        cow = output;

        Resources resources = getResources();

        //IB Grla
        TextView tvGrlib = (TextView) findViewById(R.id.tvGrlib);
        tvGrlib.setText(cow.getGrlib());

        //Ime grla
        if (cow.getGrlime() == "" ) {
            TableRow trGrlime = (TableRow) findViewById(R.id.trGrlime);
            trGrlime.setVisibility(View.GONE);
        }
        else {
            TextView tvGrlime = (TextView) findViewById(R.id.tvGrlime);
            tvGrlime.setText(cow.getGrlime());
        }

        //Kategorija grla
        TextView tvKnjgk = (TextView) findViewById(R.id.tvKnjgk);
        tvKnjgk.setText(String.format(resources.getString(R.string.kategorija), cow.getNazkg(), cow.getKnjgk()));

        //Repro status
        TextView tvRepro = (TextView) findViewById(R.id.tvRepro);
        tvRepro.setText(String.format(resources.getString(R.string.GrloInfo1), cow.getRepro(), cow.getReproDate().toString("dd.MM.yyyy")));

        //Faza laktacije
        TextView tvFazal = (TextView) findViewById(R.id.tvFazal);
        tvFazal.setText(String.format(resources.getString(R.string.GrloInfo2), cow.getFazal(), cow.getBrlak(), cow.getDanul()));

        //Datum rodjenja
        TextView tvDatRodj = (TextView) findViewById(R.id.tvDatRodj);
        //tvDatRodj.setText(String.format(resources.getString(R.string.kategorija), cow.getNazkg(), cow.getKnjgk()));
        tvDatRodj.setText(cow.getDatRodj().toString("dd.MM.yyyy"));


/*        List<PointValue> values = new ArrayList<PointValue>();
        values.add(new PointValue(0, 2));
        values.add(new PointValue(1, 4));
        values.add(new PointValue(2, 3));
        values.add(new PointValue(3, 4));

        //In most cased you can call data model methods in builder-pattern-like manner.
        Line line = new Line(values).setColor(Color.BLUE).setCubic(true);
        List<Line> lines = new ArrayList<Line>();
        lines.add(line);

        LineChartData data = new LineChartData();
        data.setLines(lines);

        LineChartView chart = (LineChartView) findViewById(R.id.lcvChart);;
        chart.setLineChartData(data);*/

        generateDefaultData();

    }

    private void generateDefaultData() {

         final int DEFAULT_DATA = 0;
         final int SUBCOLUMNS_DATA = 1;
         final int STACKED_DATA = 2;
         final int NEGATIVE_SUBCOLUMNS_DATA = 3;
         final int NEGATIVE_STACKED_DATA = 4;

        //private ColumnChartView chart;
         ColumnChartData data;
         boolean hasAxes = true;
         boolean hasAxesNames = true;
         boolean hasLabels = true;
         boolean hasLabelForSelected = false;
         int dataType = DEFAULT_DATA;

        int numSubcolumns = 1;
        int numColumns = 7;

        // Column can have many subcolumns, here by default I use 1 subcolumn in each of 8 columns.
        List<Column> columns = new ArrayList<Column>();
        List<SubcolumnValue> values;
        List<AxisValue> axisValuesX = new ArrayList<AxisValue>();

        for (int i = 0; i < numColumns; ++i) {

            values = new ArrayList<SubcolumnValue>();
            for (int j = 0; j < numSubcolumns; ++j) {
                //values.add(new SubcolumnValue((float) Math.random() * 50f + 5, ChartUtils.pickColor()));

                //Dodeli vrednosti za stubiće
                SubcolumnValue helpSCV = new SubcolumnValue();
                helpSCV.setColor(Color.parseColor("#99CC00"));
                helpSCV.setValue((int) Math.round((float) Math.random() * 30f + 5));
                //helpSCV.setLabel("0"+Integer.toString(i)+".04.2020");
                values.add(helpSCV);

                //Postavi nazive na X osi
                AxisValue axisValue = new AxisValue((float) 0.0);
                axisValue.setLabel("0"+Integer.toString(i+1)+".apr");
                axisValue.setValue(i);
                axisValuesX.add(axisValue);

            }

            Column column = new Column(values);
            column.setHasLabels(hasLabels);
            column.setHasLabelsOnlyForSelected(hasLabelForSelected);
            columns.add(column);

        }

        data = new ColumnChartData(columns);

        if (hasAxes) {
            Axis axisX = new Axis();

            axisX.setValues(axisValuesX);
            axisX.setHasTiltedLabels(true);
            Axis axisY = new Axis().setHasLines(true);
            if (hasAxesNames) {
                axisX.setName("Datum");
                axisY.setName("Litara mleka");
            }
            data.setAxisXBottom(axisX);
            data.setAxisYLeft(axisY);
        } else {
            data.setAxisXBottom(null);
            data.setAxisYLeft(null);
        }

        ColumnChartView chart = (ColumnChartView) findViewById(R.id.ccvChart);;
        chart.setColumnChartData(data);

    }

}
