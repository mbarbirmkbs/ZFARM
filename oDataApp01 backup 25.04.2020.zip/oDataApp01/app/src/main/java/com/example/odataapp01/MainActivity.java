package com.example.odataapp01;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.odataapp01.data.CowState;
import com.example.odataapp01.helpClasses.CowsAsyncTask;
import com.example.odataapp01.helpClasses.CowsListAdapter;
import android.os.Bundle;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AsyncResponseMain {

    private RecyclerView rvCows;
    private ArrayList<CowState> cows;
    private ProgressBar myProgressBar;
    private CowsAsyncTask myAsyncTask;
    private CowsListAdapter myAdapter;
    private int currentListSize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

/*      pDialog = new ProgressDialog(PartnerLagerActivity.this);
        pDialog.setMessage(getResources().getString(R.string.loading_data));
        pDialog.setCancelable(true);
        pDialog.show();*/

        setContentView(R.layout.activity_main);

/*        ConstraintLayout layout = findViewById(R.id.main_content);
        myProgressBar = new ProgressBar(MainActivity.this, null, android.R.attr.progressBarStyleLarge);
        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(100, 100);
        params. addRule(ConstraintLayout.CENTER_IN_PARENT);
        layout.addView(myProgressBar);*/

        //Show progress bar
        ProgressBar myProgressBar = findViewById(R.id.progressBar);
        myProgressBar.setVisibility(View.VISIBLE);

        // Lookup the recyclerview in activity layout
        rvCows = findViewById(R.id.rvCows);;

        // Set layout manager to position the items
        rvCows.setLayoutManager(new LinearLayoutManager(this));

        // Create adapter passing in the empty data
        myAdapter = new CowsListAdapter(cows);
        currentListSize = 0;

        // Attach the adapter to the recyclerview to populate items
        rvCows.setAdapter(myAdapter);

        //cows = new ArrayList<CowState>();

        //new callService(this).execute();

        myAsyncTask = new CowsAsyncTask();

        //this to set delegate/listener back to this class
        myAsyncTask.delegate = this;

        //execute the async task
        myAsyncTask.execute();

    }

    //this override the implemented method from asyncTask
    @Override
    //public void processFinish(String output){
    public void processFinish(ArrayList<CowState> output){
        //Here you will receive the result fired from async class
        //of onPostExecute(result) method.
        cows = output;

        // Create adapter passing in the sample user data
        myAdapter = new CowsListAdapter(cows);

        //Hide progress bar when finished
        ProgressBar myProgressBar = findViewById(R.id.progressBar);
        myProgressBar.setVisibility(View.GONE);

        if (cows != null && cows.size() > 0) {

            // Set layout manager to position the items
            rvCows.setLayoutManager(new LinearLayoutManager(this));
            //Attach the adapter to the recyclerview to populate items
            rvCows.setAdapter(myAdapter);
            myAdapter.notifyItemRangeInserted(currentListSize, cows.size());
            myAdapter.notifyDataSetChanged();

        } else {

            Toast.makeText(this, "Nema krava na listi!",
                    Toast.LENGTH_LONG).show();

        }



/*        rvCows.setClickable(true);
        rvCows.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {

                Object myListItem = rvCows.getItemAtPosition(position);
                CowState selectedCow = (CowState) myListItem;
//                Toast.makeText(MainActivity.this, "You Clicked at " + cows.get(+position), Toast.LENGTH_SHORT).show();
                Intent detailsIntent = new Intent(MainActivity.this, DetailsActivity.class);
                detailsIntent.putExtra("EXTRA_BUKRS", selectedCow.getBukrs());
                detailsIntent.putExtra("EXTRA_GRLID", selectedCow.getGrlid());
                startActivity(detailsIntent);
            }
        });*/

    }

}
