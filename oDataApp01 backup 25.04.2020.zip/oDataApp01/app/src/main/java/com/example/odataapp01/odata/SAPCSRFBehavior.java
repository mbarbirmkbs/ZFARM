package com.example.odataapp01.odata;

import javax.ws.rs.core.MultivaluedMap;

import org.odata4j.consumer.ODataClientRequest;
import org.odata4j.jersey.consumer.behaviors.JerseyClientBehavior;

import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientRequest;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.filter.ClientFilter;
import com.sun.jersey.api.client.filter.Filterable;

public class SAPCSRFBehavior implements JerseyClientBehavior {  
    private String xcsrfToken = "";  
    
    @Override  
    public ODataClientRequest transform(ODataClientRequest request) {  
        if(request.getMethod().equals("GET")){  
            request = request.header("X-CSRF-Token", "Fetch")
            		.header("X-Requested-With", "XMLHttpRequest");  
            return request;  
        }else{  
            request = request.header("X-CSRF-Token", this.xcsrfToken)
            		.header("X-Requested-With", "XMLHttpRequest");  
            return request;  
        }  
          
    }  
    @Override  
    public void modify(ClientConfig arg0) {  
        // TODO Auto-generated method stub  
          
    }  
    @Override  
    public void modifyClientFilters(Filterable client) {  
        client.addFilter(new ClientFilter(){  
            @Override  
            public ClientResponse handle(ClientRequest clientRequest)  
                    throws ClientHandlerException {  
                ClientResponse response = this.getNext().handle(clientRequest);  
                MultivaluedMap<String, String> headers = response.getHeaders();  
                xcsrfToken = headers.getFirst("X-CSRF-Token");  
                System.out.println("Token: " + xcsrfToken);  
                return response;  
            }  
         });  
    }  
    @Override  
    public void modifyWebResourceFilters(Filterable arg0) {  
        // TODO Auto-generated method stub  
          
    }
}
