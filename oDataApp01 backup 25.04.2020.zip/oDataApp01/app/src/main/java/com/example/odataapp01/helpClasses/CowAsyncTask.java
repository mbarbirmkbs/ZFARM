package com.example.odataapp01.helpClasses;

import android.os.AsyncTask;

import com.example.odataapp01.AsyncResponseDetails;
import com.example.odataapp01.MainActivity;
import com.example.odataapp01.data.CowState;
import com.example.odataapp01.odata.SAPCSRFBehavior;
import com.sun.jersey.api.client.ClientHandlerException;

import org.joda.time.LocalDateTime;
import org.odata4j.consumer.ODataConsumer;
import org.odata4j.consumer.ODataConsumers;
import org.odata4j.consumer.behaviors.BasicAuthenticationBehavior;
import org.odata4j.core.OEntity;
import org.odata4j.core.OEntityKey;
import org.odata4j.core.UnsignedByte;
import org.odata4j.exceptions.ServerErrorException;

import java.lang.ref.WeakReference;
import java.util.Date;

public class CowAsyncTask extends AsyncTask<String, Integer, String> {

    public AsyncResponseDetails delegate = null;

    private WeakReference<MainActivity> activityReference;
    private CowState cow = new CowState();
    private String errorMsg = "";

    // only retain a weak reference to the activity
    public CowAsyncTask(MainActivity context) {
        activityReference = new WeakReference<>(context);
    }

    public CowAsyncTask() {

    }

    @Override
    protected String doInBackground(String[] args) {

        // do some long running task...

        String bukrs = args[0];
        String grlid = args[1];

        String serviceUrl = "http://mkitsap.mk-group.org:8055/sap/opu/odata/sap/ZFARM_TEST_01_SRV/";

        String user = "MBARBIR";
        String pass = "Sonequa1546";

        String lvResult = null;
        org.odata4j.core.UnsignedByte lvByte;

        try {

            ODataConsumer consumer;
            consumer = ODataConsumers.create(serviceUrl);
            ODataConsumer.Builder builder = ODataConsumers.newBuilder(serviceUrl);
            builder.setClientBehaviors( new BasicAuthenticationBehavior(user, pass), new SAPCSRFBehavior());
            consumer = builder.build();

            OEntityKey cowKey = OEntityKey.create("Bukrs", bukrs, "Grlid", grlid);
            //OEntityKey cowKey = OEntityKey.create("Bukrs", "1000", "Grlid", "1001000006");

            OEntity GrloCardSet = consumer.getEntity("GrloCardSet", cowKey ).execute();

            lvByte = (UnsignedByte) GrloCardSet.getProperty("Brlak").getValue();

            cow = new CowState(
                GrloCardSet.getProperty("Bukrs").getValue().toString(),
                GrloCardSet.getProperty("Grlid").getValue().toString(),
                GrloCardSet.getProperty("Grlib").getValue().toString(),
                GrloCardSet.getProperty("Knjgk").getValue().toString(),
                GrloCardSet.getProperty("Nazkg").getValue().toString(),
                GrloCardSet.getProperty("Grlime").getValue().toString(),
                GrloCardSet.getProperty("Repro").getValue().toString(),
                ((LocalDateTime) GrloCardSet.getProperty("ReproDate").getValue()),
                ((LocalDateTime) GrloCardSet.getProperty("Datrodj").getValue()),
                GrloCardSet.getProperty("Fazal").getValue().toString(),
                lvByte.toString(),
                (Integer) GrloCardSet.getProperty("Danul").getValue()
            );

        } catch (ClientHandlerException e) {

            //errorMsg = "Calling service for cow details went wrong!";
            errorMsg = e.getMessage();

        } catch (ServerErrorException e) {

            //errorMsg = "Calling service for cow details went wrong!";
            errorMsg = e.getMessage();

        }

        return "OK";
    }

    @Override
    protected void onPostExecute(String result) {

        delegate.processFinish(cow);

    }



}